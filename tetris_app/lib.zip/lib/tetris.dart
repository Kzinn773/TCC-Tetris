import 'dart:math';

enum TetrominoShape { I, O, T, S, Z, J, L }

class Tetromino {
  final TetrominoShape shape;
  List<List<int>> matrix;
  int x;
  int y;

  Tetromino(this.shape, this.matrix, {this.x = 0, this.y = 0});

  factory Tetromino.create(TetrominoShape shape, {int boardCols = 10}) {
    List<List<int>> matrix;

    switch (shape) {
      case TetrominoShape.I:
        matrix = [
          [0, 0, 0, 0],
          [1, 1, 1, 1],
          [0, 0, 0, 0],
          [0, 0, 0, 0],
        ];
        break;
      case TetrominoShape.O:
        matrix = [
          [2, 2],
          [2, 2],
        ];
        break;
      case TetrominoShape.T:
        matrix = [
          [0, 3, 0],
          [3, 3, 3],
          [0, 0, 0],
        ];
        break;
      case TetrominoShape.S:
        matrix = [
          [0, 4, 4],
          [4, 4, 0],
          [0, 0, 0],
        ];
        break;
      case TetrominoShape.Z:
        matrix = [
          [5, 5, 0],
          [0, 5, 5],
          [0, 0, 0],
        ];
        break;
      case TetrominoShape.J:
        matrix = [
          [6, 0, 0],
          [6, 6, 6],
          [0, 0, 0],
        ];
        break;
      case TetrominoShape.L:
        matrix = [
          [0, 0, 7],
          [7, 7, 7],
          [0, 0, 0],
        ];
        break;
    }

    int startX = (boardCols - matrix[0].length) ~/ 2;
    return Tetromino(shape, matrix, x: startX, y: 0);
  }

  factory Tetromino.random({int boardCols = 10}) {
    final shapes = TetrominoShape.values;
    final randomShape = shapes[Random().nextInt(shapes.length)];
    return Tetromino.create(randomShape, boardCols: boardCols);
  }

  void rotate() {
    int n = matrix.length;
    List<List<int>> rotated = List.generate(n, (_) => List.filled(n, 0));

    for (int r = 0; r < n; r++) {
      for (int c = 0; c < n; c++) {
        rotated[c][n - 1 - r] = matrix[r][c];
      }
    }
    matrix = rotated;
  }

  // [Linha 85 - NOVA]: Rotação no sentido anti-horário
  void rotateCounterClockwise() {
    int n = matrix.length;
    List<List<int>> rotated = List.generate(n, (_) => List.filled(n, 0));

    for (int r = 0; r < n; r++) {
      for (int c = 0; c < n; c++) {
        rotated[n - 1 - c][r] = matrix[r][c];
      }
    }
    matrix = rotated;
  }
}

class TetrisGame {
  final int rows = 20;
  final int cols = 10;

  late List<List<int>> board;
  late Tetromino currentPiece;
  bool isGameOver = false;
  int score = 0;

  TetrisGame() {
    reset();
  }

  void reset() {
    board = List.generate(rows, (_) => List.filled(cols, 0));
    currentPiece = Tetromino.random(boardCols: cols);
    isGameOver = false;
    score = 0;
  }

  void tick() {
    if (isGameOver) return;

    if (!movePiece(0, 1)) {
      lockPiece();
      clearLines();
      spawnNextPiece();
    }
  }

  bool movePiece(int dx, int dy) {
    if (_checkCollision(currentPiece.matrix, currentPiece.x + dx, currentPiece.y + dy)) {
      return false;
    }
    currentPiece.x += dx;
    currentPiece.y += dy;
    return true;
  }

  // [Linha 138 - ALTERADA]: Suporte para alternar a direção da rotação
  bool rotatePiece({bool clockwise = true}) {
    final originalMatrix = currentPiece.matrix.map((row) => List<int>.from(row)).toList();

    if (clockwise) {
      currentPiece.rotate();
    } else {
      currentPiece.rotateCounterClockwise();
    }

    if (_checkCollision(currentPiece.matrix, currentPiece.x, currentPiece.y)) {
      currentPiece.matrix = originalMatrix;
      return false;
    }
    return true;
  }

  bool _checkCollision(List<List<int>> matrix, int px, int py) {
    for (int r = 0; r < matrix.length; r++) {
      for (int c = 0; c < matrix[r].length; c++) {
        if (matrix[r][c] != 0) {
          int boardX = px + c;
          int boardY = py + r;

          if (boardX < 0 || boardX >= cols || boardY >= rows) return true;
          if (boardY >= 0 && board[boardY][boardX] != 0) return true;
        }
      }
    }
    return false;
  }

  void lockPiece() {
    for (int r = 0; r < currentPiece.matrix.length; r++) {
      for (int c = 0; c < currentPiece.matrix[r].length; c++) {
        int cellValue = currentPiece.matrix[r][c];
        if (cellValue != 0) {
          int boardY = currentPiece.y + r;
          int boardX = currentPiece.x + c;

          if (boardY >= 0 && boardY < rows && boardX >= 0 && boardX < cols) {
            board[boardY][boardX] = cellValue;
          }
        }
      }
    }
  }

  void spawnNextPiece() {
    currentPiece = Tetromino.random(boardCols: cols);
    if (_checkCollision(currentPiece.matrix, currentPiece.x, currentPiece.y)) {
      isGameOver = true;
    }
  }

  void clearLines() {
    int linesCleared = 0;

    for (int r = rows - 1; r >= 0; r--) {
      if (!board[r].contains(0)) {
        board.removeAt(r);
        board.insert(0, List.filled(cols, 0));
        linesCleared++;
        r++;
      }
    }

    if (linesCleared > 0) {
      score += _calculateScore(linesCleared);
    }
  }

  int _calculateScore(int lines) {
    const points = [0, 100, 300, 500, 800];
    return lines < points.length ? points[lines] : lines * 200;
  }

  List<List<int>> getDisplayBoard() {
    List<List<int>> display = List.generate(rows, (r) => List<int>.from(board[r]));

    for (int r = 0; r < currentPiece.matrix.length; r++) {
      for (int c = 0; c < currentPiece.matrix[r].length; c++) {
        int cellValue = currentPiece.matrix[r][c];
        if (cellValue != 0) {
          int boardY = currentPiece.y + r;
          int boardX = currentPiece.x + c;

          if (boardY >= 0 && boardY < rows && boardX >= 0 && boardX < cols) {
            display[boardY][boardX] = cellValue;
          }
        }
      }
    }
    return display;
  }
}