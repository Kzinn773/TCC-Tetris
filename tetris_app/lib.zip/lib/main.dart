import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'tetris.dart'; // [Linha 4]: Importa a lógica do jogo

void main() {
  runApp(const TetrisApp());
}

class TetrisApp extends StatelessWidget {
  const TetrisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tetris em Flutter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const TetrisGameScreen(),
    );
  }
}

class TetrisGameScreen extends StatefulWidget {
  const TetrisGameScreen({super.key});

  @override
  State<TetrisGameScreen> createState() => _TetrisGameScreenState();
}

class _TetrisGameScreenState extends State<TetrisGameScreen> {
  late TetrisGame game;
  Timer? timer;
  final FocusNode _focusNode = FocusNode();

  // [Linha 35 - NOVA]: Alterna entre rotação no sentido horário e anti-horário
  bool isClockwise = true;

  // Cores de cada peça
  final Map<int, Color> blockColors = {
    0: Colors.black26,
    1: Colors.cyan,
    2: Colors.yellow,
    3: Colors.purple,
    4: Colors.green,
    5: Colors.red,
    6: Colors.blue,
    7: Colors.orange,
  };

  @override
  void initState() {
    super.initState();
    game = TetrisGame();
    _startGameLoop();
  }

  void _startGameLoop() {
    timer = Timer.periodic(const Duration(milliseconds: 500), (t) {
      if (!game.isGameOver) {
        setState(() {
          game.tick();
        });
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    _focusNode.dispose();
    super.dispose();
  }

  // [Linhas 71-89 - CONTROLES]: Captura das teclas especificadas
  void _handleKeyEvent(KeyEvent event) {
    if (event is KeyDownEvent && !game.isGameOver) {
      setState(() {
        // 'D' move para a ESQUERDA (-1, 0)
        if (event.logicalKey == LogicalKeyboardKey.keyD) {
          game.movePiece(-1, 0);
        } 
        // 'A' move para a DIREITA (1, 0)
        else if (event.logicalKey == LogicalKeyboardKey.keyA) {
          game.movePiece(1, 0);
        } 
        // ESPAÇO acelera a queda (executa o tick)
        else if (event.logicalKey == LogicalKeyboardKey.space) {
          game.tick();
        } 
        // 'S' inverte o sentido de rotação e rotaciona a peça
        else if (event.logicalKey == LogicalKeyboardKey.keyS) {
          isClockwise = !isClockwise;
          game.rotatePiece(clockwise: isClockwise);
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final displayBoard = game.getDisplayBoard();

    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        title: Text('Tetris - Pontuação: ${game.score} | Sentido: ${isClockwise ? "Horário ↻" : "Anti-horário ↺"}'),
        centerTitle: true,
      ),
      body: KeyboardListener(
        focusNode: _focusNode,
        autofocus: true,
        onKeyEvent: _handleKeyEvent,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (game.isGameOver)
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        game.reset();
                      });
                    },
                    child: const Text('Fim de Jogo! Clique para Reiniciar'),
                  ),
                ),
              Container(
                width: 250,
                height: 500,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 10,
                  ),
                  itemCount: game.rows * game.cols,
                  itemBuilder: (context, index) {
                    int r = index ~/ game.cols;
                    int c = index % game.cols;
                    int value = displayBoard[r][c];

                    return Container(
                      margin: const EdgeInsets.all(1),
                      decoration: BoxDecoration(
                        color: blockColors[value] ?? Colors.white,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}